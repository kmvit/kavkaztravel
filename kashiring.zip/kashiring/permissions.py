from rest_framework.permissions import BasePermission, SAFE_METHODS

from rest_framework.permissions import BasePermission, SAFE_METHODS

class IsOwnerOrReadOnly(BasePermission):
    """
    Разрешает изменение и удаление только владельцу объекта.
    Остальные могут только просматривать (GET, HEAD, OPTIONS).
    """

    def has_object_permission(self, request, view, obj):
        # Разрешаем доступ для методов чтения (GET, HEAD, OPTIONS) всем пользователям
        if request.method in SAFE_METHODS:
            return True

        # Разрешаем изменение и удаление только владельцу
        if request.method in ["PATCH", "PUT", "DELETE"]:
            return obj.owner == request.user

        # В других случаях всегда возвращаем True
        return True

